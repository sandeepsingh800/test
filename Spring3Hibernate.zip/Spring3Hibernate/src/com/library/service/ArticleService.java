package com.library.service;

import java.util.List;

import com.library.model.Article;

public interface ArticleService {

	public void addArticle(Article article);

	public List<Article> listArticles();
}