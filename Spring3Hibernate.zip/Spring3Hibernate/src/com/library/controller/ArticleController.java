package com.library.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.danga.MemCached.MemCachedClient;
import com.library.model.Article;
import com.library.service.ArticleService;

@Controller
@RequestMapping("/articles")
public class ArticleController {

	@Autowired
	private ArticleService articleService;

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView saveArticle(@ModelAttribute("article") Article  article, BindingResult result) {
		articleService.addArticle(article);

		return new ModelAndView("redirect:/articles.html");
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView listArticles() {
		System.out.println("inside list of article");
		MemCachedClient mc = new MemCachedClient();
		List<Article> lsArticle= new ArrayList<Article>();
		String key   = "listArticle";
		
		
		//Object obj[] = new String{"A","S"};
		
		Map<String, Object> model = new HashMap<String, Object>();
		
		
		     if(mc !=null && mc.get("listArticle") !=null)
		     {
		    	 System.out.println("List Article is present in Cache ");
		    	 lsArticle = (List<Article>) mc.get("listArticle");
		     }
		     else
		     {
		    	 System.out.println("List Article is NOT present in Cache ");
		    	 lsArticle = articleService.listArticles();
		    	 
		    	 mc.add("listArticle", lsArticle);
		     }
	        
		
		model.put("articles", lsArticle);

		return new ModelAndView("articlesList", model);
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView addArticle(@ModelAttribute("article") Article article, BindingResult result) {
		
		return new ModelAndView("addArticle");
	}
}
