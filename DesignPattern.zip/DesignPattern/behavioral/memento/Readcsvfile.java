package memento;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Readcsvfile {

	public static void main(String[] args) {
		String filename = "C:/Users/Sandeep/Downloads/data.csv";
		File file = new File(filename);
		try {
			Scanner s1 = new Scanner(file);
			//InputStream inputStream;
			while(s1.hasNext()	){
				String data = s1.next();
				System.out.println(data);
			}
			s1.close();
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}	}
		
		

	}
