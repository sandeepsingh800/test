# Sphere

When bored, I sometimes open a blank JavaScript 
file and start writing without any clear objective 
of where I want to take it. This is the result of one 
such coding session.

After some fiddling and minification I was able to 
squeeze the JavaScript source into 372 bytes.

Curious about how this looks in action? [Check out the live demo.](http://hakim.se/experiments/html5/sphere).

# License

MIT licensed

Copyright (C) 2011 Hakim El Hattab, http://hakim.se