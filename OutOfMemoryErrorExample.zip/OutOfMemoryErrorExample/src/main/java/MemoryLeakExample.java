package main.java;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MemoryLeakExample {
	public static void main(String[] args) {
		Random random = new Random();
		Map<Integer, String> sampleMap = new HashMap<Integer, String>();
		
		// Loop forever...
		while(true) {
			// Create and store a random pair.
			int randomValue = random.nextInt();
			sampleMap.put(randomValue, String.valueOf(randomValue));
		}
	}
}
